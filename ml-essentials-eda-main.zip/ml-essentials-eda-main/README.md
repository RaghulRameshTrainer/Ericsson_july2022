[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/fenago/eda/HEAD)

# eda
